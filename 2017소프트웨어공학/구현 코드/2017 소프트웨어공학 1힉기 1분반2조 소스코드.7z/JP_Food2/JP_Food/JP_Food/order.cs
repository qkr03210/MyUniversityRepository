﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace JP_Food
{

    public partial class 발주관리 : Form
    {
        Form dlg = null;
        string strConn = "Server=localhost;Port=3306;User=root;Password=wns1024;Database=j&p_food_system";
        MySqlConnection conn = null;
        DataSet DS = null;
        public int onumber;
        public 발주관리()
        {
            InitializeComponent();

            try
            {
                conn = new MySqlConnection(strConn);
                conn.Open();
                //MessageBox.Show("연결성공");
            }
            catch (MySqlException error)
            {
                MessageBox.Show(error.ToString());
            }
            if (conn == null || conn.State != ConnectionState.Open)
            {
                MessageBox.Show("Not Connected");
                return;
            }
            string sql = "SELECT * FROM 발주서  NATURAL JOIN 직원;";
            MySqlDataAdapter DBAdapter = new MySqlDataAdapter(sql, conn);
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            MySqlDataReader R = cmd.ExecuteReader();
            int i = 0;
            if (R.HasRows)
            {
                // int i = 0;
                while (R.Read())
                {
                    ListViewItem lvt = new ListViewItem();
                    lvt.SubItems.Add(R.GetString(1));
                    lvt.SubItems.Add(R.GetString(2));
                    lvt.SubItems.Add(R.GetString(3));
                    // lvt.SubItems.Add(R.GetString(3));
                    listView1.Items.Add(lvt);
                    i++;
                }


            }
            else { MessageBox.Show("데이터가없습니다"); onumber = 0; }
            onumber = i;
           // MessageBox.Show(Convert.ToString(onumber));

            R.Close();
        }
        public void listviewrefresh()
        {
            listView1.Items.Clear();
            string sql = "SELECT * FROM 발주서  NATURAL JOIN 직원;";
            MySqlDataAdapter DBAdapter = new MySqlDataAdapter(sql, conn);
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            MySqlDataReader R = cmd.ExecuteReader();
            int i = 0;
            if (R.HasRows)
            {
                // int i = 0;
                while (R.Read())
                {
                    ListViewItem lvt = new ListViewItem();
                    lvt.SubItems.Add(R.GetString(1));
                    lvt.SubItems.Add(R.GetString(2));
                    lvt.SubItems.Add(R.GetString(3));
                    // lvt.SubItems.Add(R.GetString(3));
                    listView1.Items.Add(lvt);
                    i++;
                }


            }
            else { MessageBox.Show("데이터가없습니다"); onumber = 0; }
            onumber = i;


            R.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //    if (dt != null) DrawTable(Graphics.FromHwnd(pictureBox1.Handle), dt);
            dlg = new Form2(this);
            dlg.ShowDialog();
        }



        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void 발주관리_Load(object sender, EventArgs e)
        {

        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listviewdoubleclick(object sender, MouseEventArgs e)
        {

            if (listView1.SelectedItems.Count == 1)
            {
                ListView.SelectedListViewItemCollection itmes = listView1.SelectedItems;
                ListViewItem lvitem = itmes[0];
                String name = lvitem.SubItems[1].Text;
                String price = lvitem.SubItems[2].Text;
                String unit = lvitem.SubItems[3].Text;
                MessageBox.Show(name + price + unit);
            }
        }

        private void columclick(object sender, ColumnClickEventArgs e)
        {
            if (listView1.Sorting == SortOrder.Ascending)
            {
                listView1.Sorting = SortOrder.Descending;
            }
            else
                listView1.Sorting = SortOrder.Ascending;


            // listView1.ListViewItemSorter= new List
        }


    }
}
