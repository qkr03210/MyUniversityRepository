﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JP_Food
{
    public partial class Employee_Register : Form
    {
        private string name = null;
        private string jumin = null;
        private string address = null;
        private string phone = null;
        private bool error = false;

        public Employee_Register()
        {
            InitializeComponent();
            comboBox1.Items.Add("010");
            comboBox1.Items.Add("011");
            comboBox1.Items.Add("018");
            comboBox1.Items.Add("019");

            textBox2.MaxLength = 6;
            textBox3.MaxLength = 7;
            textBox4.MaxLength = 4;
            textBox5.MaxLength = 4;
        }


        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))    //숫자와 백스페이스를 제외한 나머지를 바로 처리
            {
                e.Handled = true;
            }
        }

       
        private void Employee_Register_Load(object sender, EventArgs e)
        {

        }

        // 확인버튼
        private void button1_Click_1(object sender, EventArgs e)
        {
            name = textBox1.Text;
            jumin = textBox2.Text + "-" + textBox3.Text;
            phone = comboBox1.Text + "-" + textBox4.Text + "-" + textBox5.Text;
            address = textBox6.Text;


            // 잘못된 입력의 예외처리
            if (name == "")
            {
                MessageBox.Show("필수정보(이름)가 입력되지 않았습니다");
                error = true;
            }
            else if (textBox2.Text == "" | textBox3.Text == "")
            {
                MessageBox.Show("필수정보(주민번호)가 입력되지 않았습니다");
                error = true;
            }
            else if (textBox4.Text == "" | textBox5.Text == "")
            {
                MessageBox.Show("필수정보(연락처)가 입력되지 않았습니다");
                error = true;
            }
            else if (address == "")
            {
                MessageBox.Show("필수정보(주소)가 입력되지 않았습니다");
                error = true;
            }
            else if (textBox2.Text.Length != 6 | textBox3.Text.Length != 7)
            {
                MessageBox.Show("주민등록번호 오류!");
                error = true;
            }
            else if (textBox4.Text.Length < 3)
            {
                MessageBox.Show("연락처 오류!");
                error = true;
            }

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";

            DialogResult = DialogResult.Yes;
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        public string getName() { return name; }
        public string getJumin() { return jumin; }
        public string getAddress() { return address; }
        public string getPhone() { return phone; }
        public bool getError() { return error; }

    }
}
