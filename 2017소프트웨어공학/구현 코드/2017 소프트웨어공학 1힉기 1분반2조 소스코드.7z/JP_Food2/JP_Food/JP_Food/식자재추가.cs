﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace JP_Food
{
    public partial class 식자재추가 : Form
    {
        string strConn = "Server=localhost;Port=3306;User=root;Password=wns1024;Database=j&p_food_system";
        MySqlConnection conn = null;
        DataSet DS = null;
        Form2 form;

        public 식자재추가(Form2 form1)
        {
            InitializeComponent();
            // listView1.Clear();
            // this.listView1.Focus();
            form = form1;
            try
            {
                conn = new MySqlConnection(strConn);
                conn.Open();
                //MessageBox.Show("연결성공");
            }
            catch (MySqlException error)
            {
                MessageBox.Show(error.ToString());
            }
            if (conn == null || conn.State != ConnectionState.Open)
            {
                MessageBox.Show("Not Connected");
                return;
            }
            string sql = "SELECT * FROM 식자재";
            MySqlDataAdapter DBAdapter = new MySqlDataAdapter(sql, conn);
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            MySqlDataReader R = cmd.ExecuteReader();

            if (R.HasRows)
            {
                int i = 0;
                while (R.Read())
                {
                    ListViewItem lvt = new ListViewItem();
                    lvt.SubItems.Add(R.GetString(1));
                    lvt.SubItems.Add(R.GetString(4));
                    lvt.SubItems.Add(R.GetString(2));
                    lvt.SubItems.Add(R.GetString(0));
                    // lvt.SubItems.Add(R.GetString(3));
                    listView1.Items.Add(lvt);
                }


            }
            else { MessageBox.Show("데이터가없습니다"); }
            R.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void 식자재추가_Load(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listView1.SelectedItems.Count == 1)
            {
                ListView.SelectedListViewItemCollection itmes = listView1.SelectedItems;
                ListViewItem lvitem = itmes[0];
                String name = lvitem.SubItems[1].Text;
                String price = lvitem.SubItems[2].Text;
                String unit = lvitem.SubItems[3].Text;
                String check = lvitem.SubItems[4].Text;
                // MessageBox.Show(check);
                //  form
            }
        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int indexnum;

            // listView1.FocusedItem.Index
            if (listView1.FocusedItem == null)
            {
                MessageBox.Show("항목을 선택하세요");
                return;
            }
            indexnum = listView1.FocusedItem.Index;
            // ListViewItem lvitem = itmes[0];
            String name = listView1.Items[indexnum].SubItems[1].Text;
            String price = listView1.Items[indexnum].SubItems[2].Text;
            String unit = listView1.Items[indexnum].SubItems[3].Text;
            String gid = listView1.Items[indexnum].SubItems[4].Text;
            // MessageBox.Show(name + price + unit,form.count);
            if (form.ncount == 10)
            {

                MessageBox.Show("더이상 추가하실수 없습니다.");
                return;
            }
            if (form.duplicationCheck(name) == -1)
            {
                MessageBox.Show("이미 추가된 식자재입니다.");
                return;
            }
            form.name[form.ncount] = name;
            form.price[form.ncount] = price;
            form.unit[form.ncount] = unit;
            form.gid[form.ncount] = gid;
            form.setTextbox(name, unit, price, form.count);
            form.count++;
            form.ncount++;
            MessageBox.Show("추가 되었습니다.");
        }
    }
}
