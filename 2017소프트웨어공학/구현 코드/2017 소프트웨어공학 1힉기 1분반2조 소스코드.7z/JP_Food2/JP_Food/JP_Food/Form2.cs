﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace JP_Food
{
    public partial class Form2 : Form
    {
        public String[] name = new String[10];//이름
        public String[] price = new String[10];//단가
        public String[] unit = new String[10];//단위
        public String[] gid = new String[10];//식자제 아이디
        public String[] gcount = new String[10];
        String[] eid = new String[10000];//직원 id
        public int orderid;
        public int count;
        public int ncount;
        public int pcount;
        public int ucount;
        Form dlg = null;
        string strConn = "Server=localhost;Port=3306;User=root;Password=wns1024;Database=j&p_food_system";
        MySqlConnection conn = null;
        DataSet DS = null;
        발주관리 form;
        public Form2(발주관리 f1)
        {
            InitializeComponent();
            initialize();
            form = f1;
            orderid = form.onumber + 1;
            try
            {
                conn = new MySqlConnection(strConn);
                conn.Open();
                //MessageBox.Show("연결성공");
            }
            catch (MySqlException error)
            {
                MessageBox.Show(error.ToString());
            }
            if (conn == null || conn.State != ConnectionState.Open)
            {
                MessageBox.Show("Not Connected");
                return;
            }
            string sql = "SELECT * FROM sys.직원;";
            MySqlDataAdapter DBAdapter = new MySqlDataAdapter(sql, conn);
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            MySqlDataReader R = cmd.ExecuteReader();
            int i = 0;
            if (R.HasRows)
            {

                while (R.Read())
                {
                    eid[i] = R.GetString(0);
                    comboBox1.Items.Add(R.GetString(1));
                    i++;
                }


            }
            else { MessageBox.Show("데이터가없습니다"); }
            R.Close();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public int duplicationCheck(String _name)
        {
            for (int i = 0; i < 10; i++)
            {
                if (name[i] == _name)
                {
                    return -1;
                }
            }
            return 1;
        }
        public void totalcalcul4(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox4.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_4_total.Text = Convert.ToString(total);
        }
        public void totalcalcul5(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox5.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_5_total.Text = Convert.ToString(total);
        }
        public void totalcalcul6(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox6.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_6_total.Text = Convert.ToString(total);
        }
        public void totalcalcul7(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox7.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_7_total.Text = Convert.ToString(total);
        }
        public void totalcalcul10(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox10.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_10_total.Text = Convert.ToString(total);
        }
        public void totalcalcul9(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox9.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_9_total.Text = Convert.ToString(total);
        }
        public void totalcalcul8(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox8.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_8_total.Text = Convert.ToString(total);
        }
        public void totalcalcul3(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox3.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_3_total.Text = Convert.ToString(total);
        }
        public void totalcalcul2(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox2.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_2_total.Text = Convert.ToString(total);
        }
        public void totalcalcul1(String price, String count)
        {

            if (price == "")
                price = "0";
            int a = Convert.ToInt32(price);
            if (a > 10000)
            {
                MessageBox.Show("10000개를 초과할수 없습니다");
                textBox1.Text = "0";
                a = 0;
            }

            int b = Convert.ToInt32(count);
            int total = a * b;
            label_1_total.Text = Convert.ToString(total);
        }

        public void setTextbox(String name, String unit, String cost, int count)
        {
            switch (count)
            {
                case 1:
                    label_1_name.Text = name;
                    label_1_unit.Text = unit;
                    label_1_price.Text = cost;
                    textBox1.Visible = true;
                    break;
                case 2:
                    label_2_name.Text = name;
                    label_2_unit.Text = unit;
                    label_2_price.Text = cost;
                    textBox2.Visible = true;
                    break;
                case 3:
                    label_3_name.Text = name;
                    label_3_unit.Text = unit;
                    label_3_price.Text = cost;
                    textBox3.Visible = true;
                    break;
                case 4:
                    label_4_name.Text = name;
                    label_4_unit.Text = unit;
                    label_4_price.Text = cost;
                    textBox4.Visible = true;
                    break;
                case 5:
                    label_5_name.Text = name;
                    label_5_unit.Text = unit;
                    label_5_price.Text = cost;
                    textBox5.Visible = true;
                    break;
                case 6:
                    label_6_name.Text = name;
                    label_6_unit.Text = unit;
                    label_6_price.Text = cost;
                    textBox6.Visible = true;
                    break;
                case 7:
                    label_7_name.Text = name;
                    label_7_unit.Text = unit;
                    label_7_price.Text = cost;
                    textBox7.Visible = true;
                    break;
                case 8:
                    label_8_name.Text = name;
                    label_8_unit.Text = unit;
                    label_8_price.Text = cost;
                    textBox8.Visible = true;
                    break;
                case 9:
                    label_9_name.Text = name;
                    label_9_unit.Text = unit;
                    label_9_price.Text = cost;
                    textBox9.Visible = true;
                    break;
                case 10:
                    label_10_name.Text = name;
                    label_10_unit.Text = unit;
                    label_10_price.Text = cost;
                    textBox10.Visible = true;
                    break;
            }
        }
        public void initialize()
        {
            count = 1;
            ncount = 0;
            ucount = 0;
            pcount = 0;
            label_1_name.Text = "";
            label_1_total.Text = "";
            label_1_price.Text = "";
            label_1_unit.Text = "";
            textBox1.Visible = false;

            label_2_name.Text = "";
            label_2_total.Text = "";
            label_2_price.Text = "";
            label_2_unit.Text = "";
            textBox2.Visible = false;

            label_3_name.Text = "";
            label_3_total.Text = "";
            label_3_price.Text = "";
            label_3_unit.Text = "";
            textBox3.Visible = false;

            label_4_name.Text = "";
            label_4_total.Text = "";
            label_4_price.Text = "";
            label_4_unit.Text = "";
            textBox4.Visible = false;

            label_5_name.Text = "";
            label_5_total.Text = "";
            label_5_price.Text = "";
            label_5_unit.Text = "";
            textBox5.Visible = false;

            label_6_name.Text = "";
            label_6_total.Text = "";
            label_6_price.Text = "";
            label_6_unit.Text = "";
            textBox6.Visible = false;

            label_7_name.Text = "";
            label_7_total.Text = "";
            label_7_price.Text = "";
            label_7_unit.Text = "";
            textBox7.Visible = false;

            label_8_name.Text = "";
            label_8_total.Text = "";
            label_8_price.Text = "";
            label_8_unit.Text = "";
            textBox8.Visible = false;

            label_9_name.Text = "";
            label_9_total.Text = "";
            label_9_price.Text = "";
            label_9_unit.Text = "";
            textBox9.Visible = false;

            label_10_name.Text = "";
            label_10_total.Text = "";
            label_10_price.Text = "";
            label_10_unit.Text = "";
            textBox10.Visible = false;



        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //  textBox1.set
            if (textBox1.Text != null)
                totalcalcul1(textBox1.Text, label_1_price.Text);
            gcount[0] = textBox1.Text;
            if (textBox1.Text == "")
            {
                gcount[0] = "0";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            totalcalcul2(textBox2.Text, label_2_price.Text);
            gcount[1] = textBox2.Text;
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //숫자,백스페이스,마이너스,소숫점 만 입력받는다.
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            totalcalcul6(textBox6.Text, label_6_price.Text);
            gcount[5] = textBox6.Text;
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            totalcalcul7(textBox7.Text, label_7_price.Text);
            gcount[6] = textBox7.Text;
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            totalcalcul8(textBox8.Text, label_8_price.Text);
            gcount[7] = textBox8.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            totalcalcul3(textBox3.Text, label_3_price.Text);
            gcount[2] = textBox3.Text;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            totalcalcul4(textBox4.Text, label_4_price.Text);
            gcount[3] = textBox4.Text;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            totalcalcul5(textBox5.Text, label_5_price.Text);
            gcount[4] = textBox5.Text;
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            totalcalcul9(textBox9.Text, label_9_price.Text);
            gcount[8] = textBox9.Text;
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            totalcalcul10(textBox10.Text, label_10_price.Text);
            gcount[9] = textBox10.Text;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dlg = new 식자재추가(this);
            dlg.ShowDialog();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)//발주하기
        {
            int count = 1;
            // MessageBox.Show(Convert.ToString(orderid));
            //      INSERT INTO `sys`.`발주서` (`Order_dreft_id`, `Employee_id`, `납기일`) VALUES ('4', '1', '2017-06-03');
            //   MessageBox.Show(comboBox1.SelectedIndex.ToString());

            int index = Convert.ToInt32(comboBox1.SelectedIndex.ToString());
            if (index == -1)
            {
                MessageBox.Show("담당자를 선택하세요");
                return;
            }
            if (ncount == 0)
            {
                MessageBox.Show("식자재를 추가하세요");
                return;
            }
            String ytoday = DateTime.Now.ToString("yyyy");
            String mtoday = DateTime.Now.ToString("MM");
            String dtoday = DateTime.Now.ToString("dd");

            System.DateTime ordertime = new System.DateTime(Convert.ToInt32(ytoday), Convert.ToInt32(mtoday), Convert.ToInt32(dtoday));
            String periodDay = ordertime.AddDays(2).ToString("yyy-MM-dd");
            // MessageBox.Show(periodDay); 

            String save = "INSERT INTO `sys`.`발주서` (`Order_dreft_id`, `Employee_id`, `납기일`) VALUES (\'" + orderid + "\',\'" + eid[index] + "\',\'" + periodDay + "\')";



            MySqlCommand cmd3 = new MySqlCommand(save, conn);
            cmd3.ExecuteNonQuery();
            for (int i = 0; i < ncount; i++)
            {
                String save1 = " INSERT INTO `sys`.`발주내역` (`Order_record`, `Order_dreft_id`, `Employee_id`, `수량`, `Groceries_id`) VALUES (\'" + count + "\',\'" + orderid + "\',\'" + eid[index] + "\',\'" + gcount[i] + "\',\'" + gid[i] + "\')";
                // VALUES ('1', '1', '3', '1', '1');
                if (gcount[i] != "0" && gcount[i] != "")
                {
                    MySqlCommand cmd4 = new MySqlCommand(save1, conn);
                    cmd4.ExecuteNonQuery();
                }


                count++;



            }


            MessageBox.Show("발주완료!", "등록성공", MessageBoxButtons.OK, MessageBoxIcon.Information);
            form.listviewrefresh();
            Close();


        }
    }
}
