﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JP_Food
{
    public partial class password_verify : Form
    {
        public string password;
        public password_verify()
        {
            InitializeComponent();
        }

        private void verify_button_Click(object sender, EventArgs e)
        {
            if(pw_textBox.Text == password)
            {
                MessageBox.Show("권한이 변경되었습니다.");
                DialogResult = DialogResult.Yes;
            }
            else
            {
                MessageBox.Show("비밀번호가 잘못입력되엇습니다");
                DialogResult = DialogResult.No;
            }
            this.Close();
        }

        private void cancle_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void verify_password(string password)
        {
            this.password = password;
        }

        private void password_verify_Load(object sender, EventArgs e)
        {

        }
    }
}
